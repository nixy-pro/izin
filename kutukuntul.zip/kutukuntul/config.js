const fs = require('fs')
//~~~~~~~~~SETTING BOT~~~~~~~~~~//
global.owner = "6285823103767"
global.namaowner = "MIKU DEVELOPER"
global.dana = "085823103767"
global.ovo = "KOSONG"
global.gopay = "KOSONG"
global.qris = "https://files.catbox.moe/j7f2zc.jpg"

//~~~~~~~~~SETTING DELAY~~~~~~~~~~//
global.delaypushkontak
global.delayjpm = "3000"

//~~~~~~~~~SETTING CPANEL~~~~~~~~~~//
global.egg = "15"
global.loc = "1"
global.domain = "-" // DOMAIN
global.apikey = "-" // PTLA
global.capikey = "-" // PTLC

//~~~~~~~~~ Settings reply ~~~~~~~~~//
global.mess = {
    owner: "    _*𝗟𝗨 𝗕𝗨𝗞𝗔𝗡 𝗕𝗔𝗡𝗚 𝗠𝗜𝗞𝗨 𝗞𝗢𝗡𝗧𝗬𝗢𝗟*_",
    prem: "   _*𝗞𝗛𝗨𝗦𝗨𝗦 𝗔𝗡𝗚𝗚𝗢𝗧𝗔 𝗕𝗔𝗡𝗚 𝗠𝗜𝗞𝗨*_",
    gb: "    _*𝗛𝗔𝗥𝗨𝗦 𝗗𝗜 𝗗𝗔𝗟𝗔𝗠 𝗚𝗥𝗨𝗕 𝗠𝗘𝗞*_",
    adm: "    _*𝗞𝗛𝗨𝗦𝗨𝗦 𝗔𝗗𝗠𝗜𝗡 𝗚𝗥𝗨𝗕 𝗔𝗡𝗝*_",
    b: "    _*𝗕𝗢𝗧 𝗩𝗘𝗟𝗨𝗠 𝗔𝗗𝗠𝗜𝗡 𝗞𝗢𝗡*_"
}


let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
