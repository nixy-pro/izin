[ Notes !! ]]
> Kyy Is A Developer, Feature Enhancer, Fixed In Akame Script, Which Starts From 0 To Dekarang And Thank You Also For The Support

# Akame Support Di Run Pada NodeJs 20 Pas, Jika 20+ Atau 20- Dia Akan Eror
# npm instal
# npm start

➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖

[ ThanksTo !! ]
> Kyy ( Pengembang ) 
> Yann ( Si Hama Tapi Guna / Sokong Fitur / Friend ) 
> Iky ( Dep Hikari Jir / Pendorong / Friend ) 
> ZansPiw ( Gatau Dia Nih Jit / Friend )
> Ndye ( Friend )
> Zull ( Friend ) 
> Penyedia WebApi
> Pengguna Script

➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖

[ Info !! ]
Whatsap Chanel ( Update And Sharing Script Akame ) 
- https://whatsapp.com/channel/0029Vb7gTNO5a2450z5MnD0k
Youtube ( Postingan Preview )
- https://www.youtube.com/@KyyXdz
Creator ( Pengembang Dll ) 
- https://wa.me/+6288286624778

➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖

