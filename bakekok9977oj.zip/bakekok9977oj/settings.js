require("./all/module.js")

//========== Setting Owner ==========//
global.owner = "DOYZTEZEYE"
global.namaowner = "DOYZTEZEYE"

//======== Setting Bot & Link ========//
global.namabot = "DOYZTEZEYE" 
global.namabot2 = "DOYZTEZEYE"
global.ownerbot = "6285283490415"
global.dbowner = "./all/database/owner.json"
global.foother = "© Copyright Doyz Imut"
global.idsaluran = "-"
global.linkgc = 'https://whatsapp.com/channel/0029VajNyapCxoAsIcvqfr1v'
global.linksaluran = "https://whatsapp.com/channel/0029VajNyapCxoAsIcvqfr1v"
global.apitokendo = '-' // API AKUN DIGITAL OCEAN ANDA
global.linkyt = 'https://www.youtube.com/@Doyzace'
global.linktele = "https://t.me/sacchinbulls"
global.packname = "DoyzTezeye"
global.author = "DoyzTezeye"
global.footer2 = '© DoyzTezeye'
global.foter1 = 'Script type Case'
global.foter2 = '𝘚𝘤𝘳𝘪𝘱𝘵 𝘴𝘪𝘮𝘱𝘭𝘦 by DoyzTezeye'

//========== Setting Event ==========//
global.welcome = false
global.autoread = false
global.anticall = true
global.owneroff = false

//==== Waktu Jeda Jpm & Pushkon ====//
global.delaypushkontak = 5500
global.delayjpm = 5500

//========= Setting Url Foto =========//
//Lihat Di Folder Media!

//========== Setting Panell ==========//
global.egg = "15"
global.loc = "1"
global.domain = "https://harusadaemote.exvlora.xyz"
global.apikey = "ptla_o9g9zG0A9lblqUvOiRsMwes3PWbxPPa3ul7J5hX1olQ"
global.capikey = "ptlc_jYDW2iHo38k7yU7Oly9wwpflivTIHAVbvQkZyyWWLPA"

//========== Setting Panell 2 ==========//
global.domain2 = "-"
global.apikey2 = "-"
global.capikey2 = "-"

//========= Setting Payment =========//
//Kalo Gak Ada Isi Aja jadi false
global.dana = "089677123444"
global.gopay = "089677123444"
global.ovo = "TF KE QRIS AJA KATA BANG DOYZ"
global.qr = fs.readFileSync("./media/qr.jpg")
                             
//========== Api Domain 1 ===========//
global.zone1 = "993a90533a172014af6e94c6721f757d"
global.apitoken1 = "xAYhJSLtHLShjWNua5QEgqbaqS8CUfzSAMFeTRGs"
global.tld1 = "ikykyoffc.my.id/"
//========== Api Domain 2 ==========//
global.zone2 = "-";
global.apitoken2 = "-";
global.tld2 = "-";
//========== Api Domain 3 ==========//
global.zone3 = "-";
global.apitoken3 = "-";
global.tld3 = "-";
//========== Api Domain 4 ==========//
global.zone4 = "-";
global.apitoken4 = "-";
global.tld4 = "-";
//========== Api Domain 5 ==========//
global.zone5 = "-";
global.apitoken5 = "-";
global.tld5 = "-";
//========== Api Domain 6 ==========//
global.zone6 = "-";
global.apitoken6 = "-";
global.tld6 = "-";

//========= Setting Message =========//
global.msg = {
"error": "Error terjadi kesalahan Bang Doyz",
"done": "Done Bang Doyz ✅", 
"wait": "Bot Sedang Memproses Tunggu Sebentar Bang Doyz . . .", 
"group": "*• Group Only* Fitur Ini Hanya Untuk Di Dalam Grup!", 
"private": "*• Private Chat* Fitur Ini Hanya Untuk Didalam Private Chat!", 
"admin": "*• Admin Only* Fitur Ini Hanya Untuk Admin Grup!", 
"adminbot": "*• Bot Admin* Fitur Ini Dapat Digunakan Ketika Bot Menjadi Admin", 
"owner": "*• Owner Only* Fitur Ini Hanya Untuk Owner Bot!", 
"developer": "*• Developer Only* Fitur Ini Hanya Untuk Developer"
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})